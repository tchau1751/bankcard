# AccountLayout Component


## Options
No options available for this component

## Install
```
import AccountLayout from 'components/AccountLayout'
```

## Examples
```
<AccountLayout />
```