# SizeList Component


## Options
No options available for this component

## Install
```
import SizeList from 'components/SizeList'
```

## Examples
```
<SizeList />
```