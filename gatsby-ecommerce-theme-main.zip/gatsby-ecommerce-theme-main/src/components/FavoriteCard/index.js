export { default } from './FavoriteCard';
