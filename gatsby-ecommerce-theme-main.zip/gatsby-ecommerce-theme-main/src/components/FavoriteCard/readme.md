# FavoriteCard Component


## Options
No options available for this component

## Install
```
import FavoriteCard from 'components/FavoriteCard'
```

## Examples
```
<FavoriteCard />
```