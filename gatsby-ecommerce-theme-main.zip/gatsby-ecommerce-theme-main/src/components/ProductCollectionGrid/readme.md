# ProductCollectionGrid Component


## Options
No options available for this component

## Install
```
import ProductCollectionGrid from 'components/ProductCollectionGrid'
```

## Examples
```
<ProductCollectionGrid />
```