# Attribute Component


## Options
No options available for this component

## Install
```
import Attribute from 'components/Attribute'
```

## Examples
```
<Attribute />
```