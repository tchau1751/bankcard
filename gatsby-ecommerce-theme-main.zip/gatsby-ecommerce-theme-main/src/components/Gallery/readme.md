# Gallery Component


## Options
No options available for this component

## Install
```
import Gallery from 'components/Gallery'
```

## Examples
```
<Gallery />
```