# ActionCard Component


## Options
No options available for this component

## Install
```
import ActionCard from 'components/ActionCard'
```

## Examples
```
<ActionCard />
```