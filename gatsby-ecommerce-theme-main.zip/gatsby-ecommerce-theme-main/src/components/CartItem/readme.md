# CartItem Component


## Options
No options available for this component

## Install
```
import CartItem from 'components/CartItem'
```

## Examples
```
<CartItem />
```