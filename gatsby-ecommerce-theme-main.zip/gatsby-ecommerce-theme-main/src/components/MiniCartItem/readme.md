# MiniCartItem Component


## Options
No options available for this component

## Install
```
import MiniCartItem from 'components/MiniCartItem'
```

## Examples
```
<MiniCartItem />
```