# Header Component


## Options
No options available for this component

## Install
```
import Header from 'components/Header'
```

## Examples
```
<Header />
```