# LayoutOption Component
An optional component that will link 2 versions of product listing page

## Options
No options available for this component

## Install
```
import LayoutOption from 'components/LayoutOption'
```

## Examples
```
<LayoutOption />
```