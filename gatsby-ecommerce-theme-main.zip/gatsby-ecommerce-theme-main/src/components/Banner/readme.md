# Banner Component


## Options
No options available for this component

## Install
```
import Banner from 'components/Banner'
```

## Examples
```
<Banner />
```