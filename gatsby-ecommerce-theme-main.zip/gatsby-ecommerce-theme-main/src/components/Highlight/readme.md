# Highlight Component


## Options
No options available for this component

## Install
```
import Highlight from 'components/Highlight'
```

## Examples
```
<Highlight />
```