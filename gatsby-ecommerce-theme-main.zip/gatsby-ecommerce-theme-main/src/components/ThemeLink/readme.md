# ThemeLink Component


## Options
No options available for this component

## Install
```
import ThemeLink from 'components/ThemeLink'
```

## Examples
```
<ThemeLink />
```