export { default } from './Brand';
