# Contact Component


## Options
No options available for this component

## Install
```
import Contact from 'components/Contact'
```

## Examples
```
<Contact />
```